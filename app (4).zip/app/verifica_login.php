<?php
session_start();
if(!$_SESSION['login_user']) {
// Redirect to login page
header('Location: login.php');
exit();
}

?>