<?php
// Initialize the session
session_start();
 
// destroy the session
session_destroy();

// Redirect to login page
header('Location: index.php');
exit();
?>
