 <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Hotel</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
        

  <li class="nav-item">
    <a class="nav-link" href="OPERACAO-index.php ">Operações</a>
  </li>
      <li class="nav-item">
    <a class="nav-link " href="reservas/index.php">Ver reservas</a>
  </li>
      <li class="nav-item">
    <a class="nav-link " href="checking/index.php">Ver checking</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="APARTAMENTO-index.php">Apartamentos</a>         
  </li>
  <li class="nav-item">
    <a class="nav-link " href="HOSP-index.php">Hóspedes</a>

  </li>  <li class="nav-item">
    <a class="nav-link " href="PRODUTOS-index.php">Produtos</a>
  </li>
  
  
  </li>  <li class="nav-item">
    <a class="nav-link " href="users-index.php">Usuários</a>
  </li>
    </li> 

   <li class="nav-item">
    <a class="nav-link " href="#"> <?php echo '  '.$_SESSION['login_user'];
 ?> </a> 
  </li>
  
  <li class="nav-item">
  <a class="nav-link "  href="logout.php" >Sair</a>
  </li> 
    </ul>
  </div>
</nav>


