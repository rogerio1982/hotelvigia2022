<?php
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=plat4478_bd;charset=utf8', 'plat4478_admin', 'admin2020');
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}
